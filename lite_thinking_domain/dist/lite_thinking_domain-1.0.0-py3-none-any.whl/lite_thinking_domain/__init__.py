"""
Lite Thinking Domain - Core de Dominio
Modelos Django reutilizables con lógica de negocio

Uso:
    from lite_thinking_domain.models import Usuario, Empresa, Producto
"""

__version__ = "1.0.0"
__author__ = "Jeffer"

# Facilitar imports directos
from lite_thinking_domain.models import (
    Usuario,
    Empresa,
    Producto,
    Inventario,
    MovimientoInventario,
    Conversacion,
    Mensaje,
)

__all__ = [
    "Usuario",
    "Empresa",
    "Producto",
    "Inventario",
    "MovimientoInventario",
    "Conversacion",
    "Mensaje",
]
