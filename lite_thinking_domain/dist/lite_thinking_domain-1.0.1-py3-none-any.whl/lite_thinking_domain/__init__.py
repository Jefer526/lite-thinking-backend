"""
Lite Thinking Domain - Core de Dominio
Modelos Django reutilizables con lógica de negocio

Uso:
    from lite_thinking_domain.models import Usuario, Empresa, Producto
"""

__version__ = "1.0.0"
__author__ = "Jeffer"

